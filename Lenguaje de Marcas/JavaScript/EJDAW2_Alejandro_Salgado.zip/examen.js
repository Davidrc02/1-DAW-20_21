window.onload = function(){

    //Inicializo las elecciones a su valor por defecto para que no se queden si se recarga la página:
    document.getElementById("c1").checked=false; 
    document.getElementById("c2").checked=false;  
    document.getElementById("color").value=0;
    //Hago la llamada al botón con onclick:
	document.getElementById("boton").onclick=inicio;
}

//La función principal, hace las llamadas a las funciones específicas en función a los valores
//seleccionados por el usuario:

function inicio(){
      
    cambiaFondo(document.getElementById("color").value); //Cambia el color del fondo.

    if(document.getElementById("c1").checked==true ){ //Si están marcados/desmarcados efectuan las funciones.
        aumentaLetra();
    }

    if(document.getElementById("c1").checked==false ){
        resetaumentaLetra();
    }
  
    if(document.getElementById("c2").checked==true ){
        colorLetra();
    }
    if(document.getElementById("c2").checked==false ){
        resetcolorLetra();
    }
}

function aumentaLetra(){
	document.body.style.fontSize = "200%";	
}

function resetaumentaLetra(){
	document.body.style.fontSize = "100%";	
}

function colorLetra(){
	document.body.style.color = "blue";	
}

function resetcolorLetra(){
	document.body.style.color = "black";	
}

function cambiaFondo(opcion){
    if(opcion == 0){
        alert("Debe seleccionar un color en la lista desplegable.")
    }
    if(opcion == 1){
        document.body.style.background = "green";
    }
    if(opcion == 2){
        document.body.style.background = "yellow";
    }
    if(opcion == 3){
        document.body.style.background = "cyan";
    }

}