// JavaScript Document

window.onload = function() { 
	//alert("al cargar página");
	document.getElementById("imagen1").onclick=tratar_imagen; 
	document.getElementById("imagen2").onclick=tratar_imagen; 
	document.getElementById("imagen3").onclick=tratar_imagen; 
	document.getElementById("imagen4").onclick=tratar_imagen; 
}

function tratar_imagen(){
	this.style.visibility="hidden";
	
}


